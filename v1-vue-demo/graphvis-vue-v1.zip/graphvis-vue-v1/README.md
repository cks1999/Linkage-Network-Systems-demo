# vue

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run dev
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

本项目可直接运行，查看运行效果。


示例数据结构：assets/demo2.js
可视化统一配置：assets/defaultConfig.js

界面功能
（1）预览界面：views/knowledgeView.vue (支持基础视图查看、属性展开、放大、缩小、适中、两种布局切换)
（2）编辑界面：views/knowledgeEditor.vue (支持拖拽新增节点、右键开始节点间连线，节点和连线的编辑)
（3）自定义节点：支持了自定义的动画效果（又节点属性openAnimation控制开启或关闭，具体业务场景自己组织，使用可参考双击时间ondblClick实现）
（4）扩展节点方法： expandNode，需要提供节点对应的关系数据。
（5）节点收起方法：contractChildNode 只会对独立的子节点进行删除收起。
（6）自定义节点示例：两种实现方案（查看view页面中的 drawDefinedNode，drawAnimateCircleNode 两个方法）。

说明：具体业务交互细节需要你们自己按照示例部分实现，如有不懂可咨询。