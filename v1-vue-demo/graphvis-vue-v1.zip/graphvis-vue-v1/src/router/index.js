import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/views/index'
import knowledgeView from '@/views/knowledgeView'
import knowledgeEditor from '@/views/knowledgeEditor'
import knowledgeNodeShadow from '@/views/knowledgeNodeShadow'
import pengGraph from '@/views/pengGraph'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'knowlege-graph',
      component:Index,
      redirect: '/knowledgeView',
      children: [
        {
          name:'knowledgeView',
          path: '/knowledgeView',
          component:knowledgeView
        },
        {
          name:'knowledgeEditor',
          path: '/knowledgeEditor',
          component:knowledgeEditor
        },
        {
          name:'knowledgeNodeShadow',
          path: '/knowledgeNodeShadow',
          component:knowledgeNodeShadow
        }
      ]
    }
  ]
})

// 路由全局导航守卫
router.beforeEach((to, from, next) => {
  /*
  if (window.sessionStorage.admin === '1') {
    return next()
  } else {
    return next('/Home')
  } */
  return next()
})

export default router
